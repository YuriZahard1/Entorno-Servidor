const path = require("path");

const express = require("express");

const rootDir = require("../util/path");

const router = express.Router();

const products = [
  {
    id: "1",
    title: "Teclado Mecánico RGB",
    price: 89.99,
    category: "Periféricos",
    description: "Teclado mecánico con switches red y retroiluminación RGB.",
  },
  {
    id: "2",
    title: 'Monitor 27" 144Hz',
    price: 219.5,
    category: "Monitores",
    description: "Panel IPS con resolución QHD y tasa de refresco de 144Hz.",
  },
];

router.get("/add-product", (req, res, next) => {
  res.render("add-product", {
    pageTitle: "Añadir Producto",
    path: "/admin/add-product",
    formsCSS: true,
    productCSS: true,
    activeAddProduct: true,
  });
});

// POST /admin/add-product
router.post("/add-product", (req, res, next) => {
  const { title, price, category, description } = req.body;

  products.push({
    id: Date.now().toString(),
    title,
    price: parseFloat(price),
    category,
    description,
  });

  res.redirect("/");
});

exports.routes = router;
exports.products = products;
